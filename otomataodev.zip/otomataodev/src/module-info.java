/**
 * 
 */
/**
 * @author Monster
 *
 */
module otomataodev {
}
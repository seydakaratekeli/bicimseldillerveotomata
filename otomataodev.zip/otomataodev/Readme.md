﻿ŞEYDA KARATEKELİOĞLU 21010310044

Readme dosyayı:

# DFA ve NFA Simülasyonu - Dil C

## Projenin Amacı
Bu proje, en az iki "a" ve iki "b" içeren tüm dizgeleri tanımlayan bir dil (Dil C) için DFA ve NFA simülatörleri geliştirmeyi amaçlamaktadır. Program, verilen bir dizgenin belirtilen otomata tarafından kabul edilip edilmediğini belirler.

## Programın Özellikleri
1. **DFA (Deterministic Finite Automaton) Simülasyonu:**
   - Deterministik bir sonlu otomata kullanılarak verilen dizgenin kabul edilip edilmediğini kontrol eder.
   - Her sembol okunduğunda otomatanın bulunduğu durumu ekrana yazdırır.

2. **NFA (Non-Deterministic Finite Automaton) Simülasyonu:**
   - Belirtilen NFA üzerinde verilen dizgenin kabul edilip edilmediğini kontrol eder.
   - NFA'nın aynı anda birden fazla durumu takip etmesi sağlanır ve bu durum adım adım gösterilir.

3. **Detaylı Durum Takibi:**
   - Program her bir sembol okunduğunda otomatanın hangi durumda olduğunu adım adım gösterir.

## Gereksinimler
- **Java 8 veya üzeri**
- Bir Java IDE (IntelliJ IDEA, Eclipse vb.) veya terminal

## Kullanım Talimatları
### Derleme ve Çalıştırma
1. **Kaynak kodu indirin:**
   Proje dosyasındaki `DFANFASimulator.java` dosyasını bir klasöre yerleştirin.

2. **Kodun derlenmesi:**
   Terminal veya bir Java IDE kullanarak aşağıdaki komutla kodu derleyin:
   ```bash
   javac DFANFASimulator.java

3. Programın çalıştırılması:
   Derleme işlemi tamamlandıktan sonra programı çalıştırmak için şu komutu kullanın:
   ```bash
   java otomataodev.DFANFASimulator

4. Giriş yapın:
   Program, bir dizge girmenizi isteyecektir. Girdiğiniz dizgenin DFA ve NFA tarafından kabul edilip edilmediği sonuç olarak ekrana yazdırılacaktır.
Örnek Test Dizgeleri
Programda aşağıdaki dizgeler test edilmiş ve çıktılar üretilmiştir:
1. `aab` - Reddedildi (REJECTED)
2. `abba` - Kabul Edildi (ACCEPTED)
3. `bbaa` - Kabul Edildi (ACCEPTED)
4. `aa` - Reddedildi (REJECTED)
Dosya Yapısı
- `DFANFASimulator.java`: Kaynak kodu.
- `README.md`: Proje ile ilgili açıklamalar.
Notlar
- DFA ve NFA geçiş tabloları kodun içerisinde tanımlanmıştır.
- DFA ve NFA, grafiksel bir çıktı yerine metin tabanlı adım adım takip sağlamak üzere tasarlanmıştır.


Program Çıktıları













Program Kodu:

package otomataodev;

import java.util.*;

public class DFANFASimulator {
    // DFA Transition Table
    private static final Map<String, Map<Character, String>> dfaTransitions = new HashMap<>();
    private static final String dfaStartState = "q0";
    private static final Set<String> dfaAcceptStates = new HashSet<>(Arrays.asList("q8"));

    // NFA Transition Table
    private static final Map<String, Map<Character, Set<String>>> nfaTransitions = new HashMap<>();
    private static final String nfaStartState = "q0";
    private static final Set<String> nfaAcceptStates = new HashSet<>(Arrays.asList("q8"));

    public static void main(String[] args) {
        // Initialize DFA and NFA transitions
        initializeDFA();
        initializeNFA();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Dil C: En az iki \"a\" ve iki \"b\" içeren tüm dizgeler ");
        System.out.println("Enter a string to test: ");
        String input = scanner.nextLine();

        // DFA Simulation
        System.out.println("\nDFA Simulation:");
        boolean isDFAAccepted = simulateDFA(input);
        System.out.println("Result: The string is " + (isDFAAccepted ? "ACCEPTED" : "REJECTED") + " by the DFA.\n");

        // NFA Simulation
        System.out.println("NFA Simulation:");
        boolean isNFAAccepted = simulateNFA(input);
        System.out.println("Result: The string is " + (isNFAAccepted ? "ACCEPTED" : "REJECTED") + " by the NFA.");
    }

    private static void initializeDFA() {
        addDFATransition("q0", 'a', "q2");
        addDFATransition("q0", 'b', "q1");
        addDFATransition("q1", 'a', "q4");
        addDFATransition("q1", 'b', "q3");
        addDFATransition("q2", 'a', "q5");
        addDFATransition("q2", 'b', "q4");
        addDFATransition("q3", 'a', "q6");
        addDFATransition("q3", 'b', "q3");
        addDFATransition("q4", 'a', "q7");
        addDFATransition("q4", 'b', "q6");
        addDFATransition("q5", 'a', "q5");
        addDFATransition("q5", 'b', "q7");
        addDFATransition("q6", 'a', "q8");
        addDFATransition("q6", 'b', "q6");
        addDFATransition("q7", 'a', "q7");
        addDFATransition("q7", 'b', "q8");
        addDFATransition("q8", 'a', "q8");
        addDFATransition("q8", 'b', "q8");
    }

    private static void initializeNFA() {
        addNFATransition("q0", 'a', "q0");
        addNFATransition("q0", 'b', "q0");
        addNFATransition("q0", 'a', "q1");
        addNFATransition("q0", 'b', "q2");
        addNFATransition("q1", 'a', "q1");
        addNFATransition("q1", 'b', "q1");
        addNFATransition("q1", 'a', "q4");
        addNFATransition("q1", 'b', "q6");
        addNFATransition("q2", 'a', "q2");
        addNFATransition("q2", 'b', "q2");
        addNFATransition("q2", 'a', "q6");
        addNFATransition("q2", 'b', "q5");
        addNFATransition("q4", 'a', "q4");
        addNFATransition("q4", 'b', "q4");
        addNFATransition("q4", 'b', "q7");
        addNFATransition("q5", 'a', "q5");
        addNFATransition("q5", 'b', "q5");
        addNFATransition("q5", 'a', "q10");
        addNFATransition("q6", 'a', "q6");
        addNFATransition("q6", 'b', "q6");
        addNFATransition("q6", 'a', "q7");
        addNFATransition("q6", 'b', "q10");
        addNFATransition("q7", 'a', "q7");
        addNFATransition("q7", 'b', "q7");
        addNFATransition("q7", 'b', "q8");
        addNFATransition("q8", 'a', "q8");
        addNFATransition("q8", 'b', "q8");
    }

    private static boolean simulateDFA(String input) {
        String currentState = dfaStartState;

        for (char symbol : input.toCharArray()) {
            System.out.println("Current State: " + currentState + ", Reading: " + symbol);
            if (!dfaTransitions.containsKey(currentState) || !dfaTransitions.get(currentState).containsKey(symbol)) {
                return false; // Invalid transition
            }
            currentState = dfaTransitions.get(currentState).get(symbol);
        }

        return dfaAcceptStates.contains(currentState);
    }

    private static boolean simulateNFA(String input) {
        // Geçerli durumları başlat
        Set<String> currentStates = new HashSet<>();
        currentStates.add(nfaStartState);

        // Tüm semboller üzerinde dolaş
        for (char symbol : input.toCharArray()) {
            System.out.println("Current States: " + currentStates + ", Reading: " + symbol);
            Set<String> nextStates = new HashSet<>();

            // Geçerli her durum için olası geçişleri kontrol et
            for (String state : currentStates) {
                if (nfaTransitions.containsKey(state) && nfaTransitions.get(state).containsKey(symbol)) {
                    nextStates.addAll(nfaTransitions.get(state).get(symbol));
                }
            }

            // Eğer geçiş yapılacak durum yoksa ve hala semboller varsa, REJECT
            if (nextStates.isEmpty()) {
                System.out.println("No valid transitions, rejecting...");
                return false;
            }

            // Geçerli durumları güncelle
            currentStates = nextStates;
        }

        // Tüm geçişler bittikten sonra kabul durumlarını kontrol et
        for (String state : currentStates) {
            if (nfaAcceptStates.contains(state)) {
                System.out.println("Final States: " + currentStates + ", ACCEPTED");
                return true;
            }
        }

        // Hiçbir kabul durumuna ulaşılmadıysa REDDET
        System.out.println("Final States: " + currentStates + ", REJECTED");
        return false;
    }


    private static void addDFATransition(String fromState, char symbol, String toState) {
        dfaTransitions.computeIfAbsent(fromState, k -> new HashMap<>()).put(symbol, toState);
    }

    private static void addNFATransition(String fromState, char symbol, String toState) {
        nfaTransitions.computeIfAbsent(fromState, k -> new HashMap<>())
                      .computeIfAbsent(symbol, k -> new HashSet<>()).add(toState);
    }
}



